/*
 * mpu6050_RJ-ELEKTRONIK.h
 *
 *  Created on: 19 avr. 2026
 *      Author: RENATYJERRY
 */

#ifndef INC_MPU6050_RJ_ELEKTRONIK_H_

#include "main.h" // Adapté pour ta F411

#include <stdbool.h>

// Adresse I2C pour HAL (0x68 décalé)
#define MPU6050_ADDR (0x68 << 1)

// Registres
#define WHO_AM_I_REG     0x75
#define PWR_MGMT_1_REG   0x6B
#define ACCEL_XOUT_H_REG 0x3B

// Structure de données complète
typedef struct {
    // Valeurs instantanées
    float ax, ay, az;
    float gx, gy, gz;
    float temp;

    // Valeurs filtrées (stables)
    float f_ax, f_ay, f_az;
} MPU6050_t;

// Prototypes
uint8_t MPU6050_Init(I2C_HandleTypeDef *hi2c);
void MPU6050_Read_All(I2C_HandleTypeDef *hi2c, MPU6050_t *DataStruct);


#endif /* INC_MPU6050_RJ_ELEKTRONIK_H_ */
