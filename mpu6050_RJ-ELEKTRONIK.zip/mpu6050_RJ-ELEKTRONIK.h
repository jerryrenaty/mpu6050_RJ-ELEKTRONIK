/*
 * mpu6050_RJ-ELEKTRONIK.h
 *
 *  Created on: 19 avr. 2026
 *      Author: RENATYJERRY
 */

#ifndef INC_MPU6050_RJ_ELEKTRONIK_H_

#include "main.h" // Adapté pour ta F411

// Adresse du périphérique (AD0 à 0)
#define MPU6050_ADDR 0x68 << 1

// Registres importants
#define WHO_AM_I_REG     0x75
#define PWR_MGMT_1_REG   0x6B
#define ACCEL_XOUT_H_REG 0x3B
#define GYRO_XOUT_H_REG  0x43

// Structure pour stocker les données
typedef struct {
    float ax, ay, az;
    float gx, gy, gz;
    float temp;
} MPU6050_t;

// Prototypes des fonctions
uint8_t MPU6050_Init(I2C_HandleTypeDef *hi2c);
void MPU6050_Read_All(I2C_HandleTypeDef *hi2c, MPU6050_t *DataStruct);



#endif /* INC_MPU6050_RJ_ELEKTRONIK_H_ */
