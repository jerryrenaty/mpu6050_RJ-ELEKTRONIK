/*
 * mpu6050_RJ-ELEKTRONIK.c
 *
 *  Created on: 19 avr. 2026
 *      Author: RENATYJERRY
 */
#include "mpu6050_RJ-ELEKTRONIK.h"



// Initialisation du capteur
uint8_t MPU6050_Init(I2C_HandleTypeDef *hi2c) {
    uint8_t check, data;

    // 1. Vérifier si le capteur répond
    HAL_I2C_Mem_Read(hi2c, MPU6050_ADDR, WHO_AM_I_REG, 1, &check, 1, 100);

    if (check == 0x68) {
        // 2. Réveil du capteur (PWR_MGMT_1 à 0)
        data = 0x00;
        HAL_I2C_Mem_Write(hi2c, MPU6050_ADDR, PWR_MGMT_1_REG, 1, &data, 1, 100);

        // 3. Configuration Accéléromètre (+/- 2g)
        data = 0x00;
        HAL_I2C_Mem_Write(hi2c, MPU6050_ADDR, 0x1C, 1, &data, 1, 100);

        return 0; // OK
    }
    return 1; // Erreur
}

// Lecture complète (Accélo + Gyro)
void MPU6050_Read_All(I2C_HandleTypeDef *hi2c, MPU6050_t *DataStruct) {
    uint8_t buffer[14];

    // Lire 14 octets à partir de ACCEL_XOUT_H
    HAL_I2C_Mem_Read(hi2c, MPU6050_ADDR, ACCEL_XOUT_H_REG, 1, buffer, 14, 100);

    // --- Accéléromètre ---
    int16_t rawAX = (int16_t)(buffer[0] << 8 | buffer[1]);
    int16_t rawAY = (int16_t)(buffer[2] << 8 | buffer[3]);
    int16_t rawAZ = (int16_t)(buffer[4] << 8 | buffer[5]);

    DataStruct->ax = (rawAX / 16384.0) * 9.81;
    DataStruct->ay = (rawAY / 16384.0) * 9.81;
    DataStruct->az = (rawAZ / 16384.0) * 9.81;

    // --- Température ---
    int16_t rawTemp = (int16_t)(buffer[6] << 8 | buffer[7]);
    DataStruct->temp = (rawTemp / 340.0) + 36.53;

    // --- Gyroscope ---
    int16_t rawGX = (int16_t)(buffer[8] << 8 | buffer[9]);
    int16_t rawGY = (int16_t)(buffer[10] << 8 | buffer[11]);
    int16_t rawGZ = (int16_t)(buffer[12] << 8 | buffer[13]);

    DataStruct->gx = rawGX / 131.0;
    DataStruct->gy = rawGY / 131.0;
    DataStruct->gz = rawGZ / 131.0;
}
